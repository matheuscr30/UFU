/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pratica2.CorreBehavior;

import pratica2.Acoes.Corre;

/**
 *
 * @author matheus
 */
public class CorreRapido extends Corre{
    public void correr(){
        System.out.println("Corre Rapido");
    }
}
