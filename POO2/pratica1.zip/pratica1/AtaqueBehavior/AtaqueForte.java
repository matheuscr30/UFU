/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pratica1.AtaqueBehavior;

import pratica1.Ataque;

/**
 *
 * @author matheus
 */
public class AtaqueForte extends Ataque{
    public void atacar(){
        System.out.println("Ataque Forte");
    }
}
