/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pratica1.CorreBehavior;

import pratica1.Corre;

/**
 *
 * @author matheus
 */
public class CorreMedio extends Corre{
    public void correr(){
        System.out.println("Corre Medio");
    }
}
