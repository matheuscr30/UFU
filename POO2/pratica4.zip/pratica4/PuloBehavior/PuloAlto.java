/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pratica4.PuloBehavior;

import pratica4.Acoes.Pulo;

/**
 *
 * @author matheus
 */
public class PuloAlto extends Pulo{
    public void pular(){
        System.out.println("Pulo Alto");
    }
}
